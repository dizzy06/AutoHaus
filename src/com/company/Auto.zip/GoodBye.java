package com.company;

public class GoodBye {

    public GoodBye() {
        System.out.println("Good Bye");
        System.out.println("Bis zum Nächstenmal (^-^)/");
    }

}
